from setuptools import setup, find_packages

# This file is kept for backward compatibility
# All configuration is now in pyproject.toml
setup()
